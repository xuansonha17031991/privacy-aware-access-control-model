﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivacyABAC.Domains
{
    class ErrorMessage
    {
        public static string NotFound = "Can not find {0} ";
    }
}
