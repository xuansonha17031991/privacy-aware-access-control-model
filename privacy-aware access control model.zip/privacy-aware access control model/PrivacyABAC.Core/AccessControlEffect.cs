﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivacyABAC.Core
{
    public enum AccessControlEffect
    {
        Permit,
        Deny,
        NotApplicable
    }
}
