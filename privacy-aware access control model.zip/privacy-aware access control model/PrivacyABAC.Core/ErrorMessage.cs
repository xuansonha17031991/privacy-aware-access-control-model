﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivacyABAC.Core
{
    static class ErrorMessage
    {
        public static string InvalidJson = "Invalid json format {0}";

        public static string MissingField = "Missing {0} field in {1}";
    }
}
