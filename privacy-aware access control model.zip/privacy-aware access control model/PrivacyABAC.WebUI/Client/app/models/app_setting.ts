export class AppSetting {
    public static API_ENDPOINT = 'http://localhost:2163/api/';
}
