
/* 
 *
 * Application typings we need
 *
 */
