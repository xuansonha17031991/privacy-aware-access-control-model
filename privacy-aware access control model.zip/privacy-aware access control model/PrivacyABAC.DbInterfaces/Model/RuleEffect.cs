﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivacyABAC.DbInterfaces.Model
{
    public static class RuleEffect
    {
        public static readonly string PERMIT = "Permit";
        public static readonly string DENY = "Deny";
    }
}
