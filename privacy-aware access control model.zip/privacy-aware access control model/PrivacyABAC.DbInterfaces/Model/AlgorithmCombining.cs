﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivacyABAC.DbInterfaces.Model
{
    public class AlgorithmCombining
    {
        public static readonly string PERMIT_OVERRIDES = "permit-overrides";

        public static readonly string DENY_OVERRIDES = "deny-overrides";
    }
}
