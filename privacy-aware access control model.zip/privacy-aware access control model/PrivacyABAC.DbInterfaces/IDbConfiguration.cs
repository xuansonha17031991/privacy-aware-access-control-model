﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrivacyABAC.DbInterfaces
{
    public interface IDbConfiguration
    {
        void SetUp();
    }
}
